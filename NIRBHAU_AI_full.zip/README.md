# NIRBHAU_AI_full — Self-hosted chatbot starter

This project is a self-hosted starter for **NIRBHAU AI**. It provides:
- Streamlit frontend (http://localhost:8501)
- FastAPI backend (http://localhost:3000/chat)
- Redis for session/history storage

**Important:** This template does NOT include a model server. You must provide a model endpoint that implements an OpenAI-compatible `/v1/chat/completions` (or adapt MODEL_URL) such as:
- HuggingFace Text-Generation-Inference (TGI)
- vLLM server
- Any OpenAI-compatible hosted API (if you prefer hosted)

## Quick start (with Docker Compose)

1. Clone or download this repo.
2. Edit `.env` or export environment variables:
   - `MODEL_URL` — URL of your model server (default: http://model:8080/v1/chat/completions)
   - `ADMIN_API_KEY` — optional API key used by backend for simple auth
3. Start (requires Docker and Docker Compose):
```bash
docker compose up --build
```
4. Open `http://localhost:8501` to use the chat UI.

## Notes
- Moderation is a simple stub; replace `simple_moderation_check` in backend/main.py with a proper moderation service.
- This is for self-hosters who will run a model server separately. See Hugging Face TGI or vLLM docs for model deployment.

## License
MIT