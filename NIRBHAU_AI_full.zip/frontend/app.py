import streamlit as st
import requests, os, json

st.set_page_config(page_title="NIRBHAU AI", page_icon="🤖", layout="wide")
st.title("NIRBHAU AI — Self-Hosted Chat")

st.markdown("""
Use this interface to chat with your self-hosted NIRBHAU model.
**Important:** Configure the backend API URL and API key (if used) in the settings panel.
""")

with st.sidebar.expander("Settings", expanded=True):
    backend_url = st.text_input("Backend URL", value=os.getenv("BACKEND_URL", "http://backend:3000/chat"))
    api_key = st.text_input("Backend API Key (optional)", type="password", value=os.getenv("BACKEND_API_KEY",""))

if "history" not in st.session_state:
    st.session_state.history = []

def send_message(prompt):
    payload = {"prompt": prompt, "user_id": st.session_state.get("user_id","guest")}
    headers = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    try:
        r = requests.post(backend_url, json=payload, headers=headers, timeout=60)
        r.raise_for_status()
        return r.json().get("reply","[no reply]")
    except Exception as e:
        return f"[Error contacting backend] {e}"

col1, col2 = st.columns([3,1])
with col1:
    prompt = st.text_area("Message", height=150)
    if st.button("Send"):
        if not prompt.strip():
            st.warning("Write something first.")
        else:
            st.session_state.history.append(("You", prompt))
            with st.spinner("NIRBHAU is thinking..."):
                resp = send_message(prompt)
            st.session_state.history.append(("NIRBHAU", resp))

with col2:
    st.markdown("## Conversation")
    for who, text in reversed(st.session_state.history[-20:]):
        if who == "You":
            st.markdown(f"**You:** {text}")
        else:
            st.markdown(f"**NIRBHAU:** {text}")
    st.markdown("---")
    if st.button("Clear"):
        st.session_state.history = []

st.markdown("---")
st.markdown("**Developer notes:** This frontend calls a backend API `/chat` that must be provided by your FastAPI service. The backend should call a model server (TGI/vLLM/OpenAI-style API).")