from fastapi import FastAPI, Request, HTTPException, Header
from pydantic import BaseModel
import os, requests, redis, json, time

app = FastAPI(title="NIRBHAU Backend")

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")
MODEL_URL = os.getenv("MODEL_URL", "http://model:8080/v1/chat/completions")
ADMIN_API_KEY = os.getenv("ADMIN_API_KEY", "change-me")
MODERATION_THRESHOLD = float(os.getenv("MODERATION_THRESHOLD", "0.5"))

# Simple redis connection
r = redis.from_url(REDIS_URL, decode_responses=True)

class ChatRequest(BaseModel):
    prompt: str
    user_id: str = "guest"
    model: str = None

def simple_moderation_check(text: str) -> bool:
    # This is a stub. Replace with an actual moderation call or rule set.
    blocked = ["kill", "bomb", "harm", "suicide", "extinct", "destroy"]
    low = text.lower()
    for b in blocked:
        if b in low:
            return True
    return False

@app.post("/chat")
async def chat_endpoint(req: ChatRequest, authorization: str = Header(None)):
    # Optional simple API key auth
    if ADMIN_API_KEY != "change-me" and authorization:
        if authorization.replace("Bearer ","") != ADMIN_API_KEY:
            raise HTTPException(status_code=401, detail="Invalid API key")
    # Moderation pre-check
    if simple_moderation_check(req.prompt):
        raise HTTPException(status_code=400, detail="Prompt blocked by moderation")
    # Build payload for model server (OpenAI-compatible)
    payload = {
        "model": req.model or os.getenv("DEFAULT_MODEL","gpt-like"),
        "messages": [{"role":"user","content": req.prompt}],
        "max_tokens": 512,
        "temperature": 0.2
    }
    start = time.time()
    try:
        resp = requests.post(MODEL_URL, json=payload, timeout=60)
        resp.raise_for_status()
        j = resp.json()
        # try to parse common response shapes
        text = None
        if isinstance(j, dict):
            if "choices" in j and len(j["choices"])>0:
                text = j["choices"][0].get("message", {}).get("content") or j["choices"][0].get("text")
            elif "response" in j:
                text = j["response"]
            elif "output" in j:
                text = j["output"]
        if text is None:
            text = json.dumps(j)[:2000]
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Error contacting model server: {e}")
    latency = time.time() - start
    # Store history in redis (limited length)
    hist_key = f"hist:{req.user_id}"
    r.rpush(hist_key, json.dumps({"prompt": req.prompt, "reply": text, "ts": time.time(), "latency": latency}))
    r.ltrim(hist_key, -100, -1)
    return {"reply": text, "latency": latency}